package za.ac.cput.environmentsustainabilitytracker_fullstack.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import za.ac.cput.environmentsustainabilitytracker_fullstack.model.Comment;
import za.ac.cput.environmentsustainabilitytracker_fullstack.model.Review;
import za.ac.cput.environmentsustainabilitytracker_fullstack.service.CommentService;

import java.util.List;

@Controller
@RequestMapping("/eco-track")
public class CommunityEngagementController {

    //It is going to handle SQL operations for the community engagement page

    @Autowired
    private CommentService commentService;

    @GetMapping("/community")
    public String communityEngagement(){
        return "CommunityEngagementWEB";// community engagement webpage.
    }

    //Create a review
    @PostMapping("/communitySubmit")
    public String saveComment(@ModelAttribute
                             Comment comment,
                             Model model) {
        //Saving the review in the database
        commentService.saveComment(comment);
        model.addAttribute("comment", comment);
        return "redirect:/communityList";

    }

    //A webpage to display all reviews
    @GetMapping("/communityList")
    public String viewCommentList(Model model){
        model.addAttribute("communityList", commentService.getAllComments());
        return "CommunityList";
    }

    @GetMapping("/communityList/edit/{commentId}")
    public String editComment(@PathVariable("commentId") Long commentId, Model model) {
        Comment comment = commentService.getCommentById(commentId);
        model.addAttribute("review", comment);
        return "CommunityEngagementWEB";
    }

    @GetMapping("/communityList/delete/{commentId}")
    public String deleteReview(@PathVariable("commentId")Long commentId) {
        commentService.deleteCommentById(commentId);
        return "redirect:/communityList";
    }

}
