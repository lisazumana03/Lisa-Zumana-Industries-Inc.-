package za.ac.cput.environmentsustainabilitytracker_fullstack.model;

//Please note that this is for the community engagement page

import jakarta.persistence.*;
import org.springframework.stereotype.Controller;

import java.time.LocalDate;

@Entity
@Table(name = "Comment")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long commentId;
    private String commentName;
    private LocalDate localDate;
    private String avatar;

    @Column(name = "Comment", length = 1000)
    private String comment;
    
    public Comment(){
        super();
    }
    
    public Comment(Long commentId, String commentName, LocalDate localDate, String avatar){
        super();
        this.commentId = commentId;
        this.commentName = commentName;
        this.localDate = localDate;
        this.avatar = avatar;
    }

    public Long getCommentId() {
        return commentId;
    }

    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    public String getCommentName() {
        return commentName;
    }

    public void setCommentName(String commentName) {
        this.commentName = commentName;
    }

    public LocalDate getLocalDate() {
        return localDate;
    }

    public void setLocalDate(LocalDate localDate) {
        this.localDate = localDate;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
