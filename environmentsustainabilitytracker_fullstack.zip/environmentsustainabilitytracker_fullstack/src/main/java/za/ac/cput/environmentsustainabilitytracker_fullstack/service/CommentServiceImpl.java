package za.ac.cput.environmentsustainabilitytracker_fullstack.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.environmentsustainabilitytracker_fullstack.model.Comment;
import za.ac.cput.environmentsustainabilitytracker_fullstack.repository.CommentRepository;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

@Service
public class CommentServiceImpl implements CommentService{

    @Autowired
    private CommentRepository commentRepository;

    @Override
    public List<Comment> getAllComments() {
        return commentRepository.findAll();
    }

    @Override
    public void saveComment(Comment comm) {
        this.commentRepository.save(comm);
    }

    @Override
    public Comment getCommentById(long commentId) {
        Optional<Comment> opt = commentRepository.findById(commentId);
        Comment comm = null;
        if(opt.isPresent()){
            comm = opt.get();
        } else {
            throw new RuntimeException("Comment id not found!");
        }
        return comm;
    }

    @Override
    public void deleteCommentById(long commentId) {
        this.commentRepository.deleteById(commentId);
    }
}//end comment implementation
