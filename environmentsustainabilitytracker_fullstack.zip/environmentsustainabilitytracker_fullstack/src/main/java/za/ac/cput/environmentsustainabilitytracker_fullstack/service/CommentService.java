package za.ac.cput.environmentsustainabilitytracker_fullstack.service;

import za.ac.cput.environmentsustainabilitytracker_fullstack.model.Comment;

import java.util.List;

public interface CommentService {
    List<Comment> getAllComments();
    void saveComment(Comment comm);
    Comment getCommentById(long commentId);
    void deleteCommentById(long commentId);
}
