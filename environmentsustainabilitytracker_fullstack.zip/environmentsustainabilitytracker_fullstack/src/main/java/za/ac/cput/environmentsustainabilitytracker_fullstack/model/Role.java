package za.ac.cput.environmentsustainabilitytracker_fullstack.model;

public enum Role {
    ADMIN("admin"),
    USER("user");

    private String role;

    private Role(String role) {
        this.role = role;
    }
    public String getRole() {
        return role;
    }
}
