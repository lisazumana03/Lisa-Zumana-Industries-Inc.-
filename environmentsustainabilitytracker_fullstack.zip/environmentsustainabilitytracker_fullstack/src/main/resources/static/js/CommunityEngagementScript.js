const form = document.querySelector('form');

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const dateInput = document.querySelector('#date');
  const selectedDate = dateInput.value;
  alert(`You selected: ${selectedDate}`);
});