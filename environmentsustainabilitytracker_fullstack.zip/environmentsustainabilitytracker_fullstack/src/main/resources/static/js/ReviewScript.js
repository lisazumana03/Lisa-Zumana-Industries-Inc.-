//This will be the code to catch the user trying to execute a empty review

document.addEventListener('DOMContentLoaded', function(){
    const form = document.getElementById('reviewForm');
    const submitBtn = document.querySelector('.submit');

    submitBtn.addEventListener('click', function(event){
        //Retrieving the form fields
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const review = document.getElementById('review').value.trim();
    const rating = document.getElementById('rating').value;

    //Catch the user if they attempt to submit empty fields
    if(name === "" || email === "" || review === "" || rating === ""){
        alert("You cannot proceed to the next page unless you fill in the fields.");
        event.preventDefault(); //prevent the form from being submitted
    } else {
        alert("Review successfully submitted");
    }
    });

    //Code for the reset button

    const resetBtn = document.querySelector('.reset');
    resetBtn.addEventListener('click', function(){
        //Retreive the form details
        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const review = document.getElementById('review').value.trim();
        const rating = document.querySelector('select').value;

        //Notifying the user that the fields are already empty
        if(name === "" || email === "" || review === "" || rating === "select"){
            alert("Fields are already empty!");
        }
    });

    //Code to press the cancel button
    const cancelBtn = document.querySelector('.cancel');
    cancelBtn.addEventListener('click', function(){
        window.history.back();// can take you back to the home page
    });
});
